import { query } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";

export const getUrl = query({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});

export const getBackgroundImages = query({
  args: {},
  handler: async (ctx) => {
    const image1 = await ctx.storage.getUrl("kg26w48rbpy3q1k7vftnnjfkzn7ryeew" as Id<"_storage">);
    const image2 = await ctx.storage.getUrl("kg27nhr9hgvy65zafd7f1dj1xx7ry3nt" as Id<"_storage">);
    return {
      image1,
      image2
    };
  },
});
