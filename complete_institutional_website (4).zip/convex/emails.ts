import { action } from "./_generated/server";
import { v } from "convex/values";
import { Resend } from "resend";

export const sendAssociationForm = action({
  args: {
    fullName: v.string(),
    documentType: v.string(),
    documentNumber: v.string(),
    nif: v.string(),
    address: v.string(),
    postalCode: v.string(),
    phone: v.string(),
    email: v.string(),
    maritalStatus: v.string(),
    profession: v.string(),
    nationality: v.string(),
    memberType: v.string(),
  },
  handler: async (ctx, args) => {
    const emailContent = `
      <h2>Nova Solicitação de Associação - AI</h2>
      
      <h3>Dados Pessoais:</h3>
      <ul>
        <li><strong>Nome Completo:</strong> ${args.fullName}</li>
        <li><strong>Tipo de Documento:</strong> ${args.documentType}</li>
        <li><strong>Número do Documento:</strong> ${args.documentNumber}</li>
        <li><strong>NIF:</strong> ${args.nif}</li>
        <li><strong>Morada:</strong> ${args.address}</li>
        <li><strong>Código Postal:</strong> ${args.postalCode}</li>
        <li><strong>Telemóvel:</strong> ${args.phone}</li>
        <li><strong>Email:</strong> ${args.email}</li>
        <li><strong>Estado Civil:</strong> ${args.maritalStatus}</li>
        <li><strong>Profissão:</strong> ${args.profession}</li>
        <li><strong>Nacionalidade:</strong> ${args.nationality}</li>
        <li><strong>Tipo de Associação:</strong> ${args.memberType}</li>
      </ul>
      
      <p><em>Formulário enviado através do site da AI - Associação contra as Injustiças</em></p>
    `;

    try {
      const resend = new Resend(process.env.CONVEX_RESEND_API_KEY);
      const { data, error } = await resend.emails.send({
        from: "AI - Formulário de Associação <contato@vainaai.pt>",
        to: ["contato@vainaai.pt"],
        subject: `Nova Solicitação de Associação - ${args.fullName}`,
        html: emailContent,
      });

      if (error) {
        console.error("Erro do Resend:", error);
        throw new Error('Falha ao enviar email: ' + JSON.stringify(error));
      }

      console.log("Email de associação enviado com sucesso:", data);
      return { success: true, data };
    } catch (error) {
      console.error("Erro ao enviar email de associação:", error);
      throw new Error("Erro ao enviar formulário. Tente novamente.");
    }
  },
});

export const sendReportForm = action({
  args: {
    type: v.string(),
    description: v.string(),
    location: v.string(),
    phone: v.optional(v.string()),
    anonymous: v.boolean(),
  },
  handler: async (ctx, args) => {
    const emailContent = `
      <h2>Nova Denúncia Recebida - AI</h2>
      
      <h3>Detalhes da Denúncia:</h3>
      <ul>
        <li><strong>Tipo de Irregularidade:</strong> ${args.type}</li>
        <li><strong>Local da Ocorrência:</strong> ${args.location}</li>
        <li><strong>Denúncia Anônima:</strong> ${args.anonymous ? 'Sim' : 'Não'}</li>
        ${args.phone ? `<li><strong>Telefone de Contacto:</strong> ${args.phone}</li>` : ''}
      </ul>
      
      <h3>Descrição:</h3>
      <p>${args.description.replace(/\n/g, '<br>')}</p>
      
      <p><em>Denúncia enviada através do site da AI - Associação contra as Injustiças</em></p>
    `;

    try {
      const resend = new Resend(process.env.CONVEX_RESEND_API_KEY);
      const { data, error } = await resend.emails.send({
        from: "AI - Canal de Denúncias <contato@vainaai.pt>",
        to: ["contato@vainaai.pt"],
        subject: `Nova Denúncia - ${args.type} em ${args.location}`,
        html: emailContent,
      });

      if (error) {
        console.error("Erro do Resend:", error);
        throw new Error('Falha ao enviar email: ' + JSON.stringify(error));
      }

      console.log("Email de denúncia enviado com sucesso:", data);
      return { success: true, data };
    } catch (error) {
      console.error("Erro ao enviar email de denúncia:", error);
      throw new Error("Erro ao enviar denúncia. Tente novamente.");
    }
  },
});

export const sendVolunteerForm = action({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.string(),
    area: v.string(),
    availability: v.string(),
    experience: v.string(),
  },
  handler: async (ctx, args) => {
    const emailContent = `
      <h2>Nova Inscrição de Voluntário - AI</h2>
      
      <h3>Dados do Voluntário:</h3>
      <ul>
        <li><strong>Nome:</strong> ${args.name}</li>
        <li><strong>Email:</strong> ${args.email}</li>
        <li><strong>Telefone:</strong> ${args.phone}</li>
        <li><strong>Área de Interesse:</strong> ${args.area}</li>
        <li><strong>Disponibilidade:</strong> ${args.availability}</li>
      </ul>
      
      <h3>Experiência Relevante:</h3>
      <p>${args.experience ? args.experience.replace(/\n/g, '<br>') : 'Não informado'}</p>
      
      <p><em>Inscrição enviada através do site da AI - Associação contra as Injustiças</em></p>
    `;

    try {
      const resend = new Resend(process.env.CONVEX_RESEND_API_KEY);
      const { data, error } = await resend.emails.send({
        from: "AI - Programa de Voluntários <contato@vainaai.pt>",
        to: ["contato@vainaai.pt"],
        subject: `Nova Inscrição de Voluntário - ${args.name}`,
        html: emailContent,
      });

      if (error) {
        console.error("Erro do Resend:", error);
        throw new Error('Falha ao enviar email: ' + JSON.stringify(error));
      }

      console.log("Email de voluntário enviado com sucesso:", data);
      return { success: true, data };
    } catch (error) {
      console.error("Erro ao enviar email de voluntário:", error);
      throw new Error("Erro ao enviar inscrição. Tente novamente.");
    }
  },
});

export const sendContactForm = action({
  args: {
    name: v.string(),
    email: v.string(),
    subject: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const emailContent = `
      <h2>Nova Mensagem de Contacto - AI</h2>
      
      <h3>Dados do Remetente:</h3>
      <ul>
        <li><strong>Nome:</strong> ${args.name}</li>
        <li><strong>Email:</strong> ${args.email}</li>
        <li><strong>Assunto:</strong> ${args.subject}</li>
      </ul>
      
      <h3>Mensagem:</h3>
      <p>${args.message.replace(/\n/g, '<br>')}</p>
      
      <p><em>Mensagem enviada através do site da AI - Associação contra as Injustiças</em></p>
    `;

    try {
      const resend = new Resend(process.env.CONVEX_RESEND_API_KEY);
      const { data, error } = await resend.emails.send({
        from: "AI - Formulário de Contacto <contato@vainaai.pt>",
        to: ["contato@vainaai.pt"],
        subject: `Contacto: ${args.subject} - ${args.name}`,
        html: emailContent,
        replyTo: args.email,
      });

      if (error) {
        console.error("Erro do Resend:", error);
        throw new Error('Falha ao enviar email: ' + JSON.stringify(error));
      }

      console.log("Email de contacto enviado com sucesso:", data);
      return { success: true, data };
    } catch (error) {
      console.error("Erro ao enviar email de contacto:", error);
      throw new Error("Erro ao enviar mensagem. Tente novamente.");
    }
  },
});
